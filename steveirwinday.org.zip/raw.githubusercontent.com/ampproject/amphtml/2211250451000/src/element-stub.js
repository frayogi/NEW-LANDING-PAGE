import {
    BaseElement
} from './base-element';

// TODO(#31915): completely eliminate this class.
export class ElementStub extends BaseElement {}