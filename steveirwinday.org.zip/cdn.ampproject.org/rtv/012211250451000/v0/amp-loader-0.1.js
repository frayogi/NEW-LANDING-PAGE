;
(self.AMP = self.AMP || []).push({
    m: 0,
    v: "2211250451000",
    n: "amp-loader",
    ev: "0.1",
    l: !0,
    f: function(a, t) {
        ! function() {
            Array.isArray;
            var t = Object.prototype,
                n = t.hasOwnProperty;

            function i(a) {
                var t = Object.create(null);
                return a && Object.assign(t, a), t
            }

            function e(a, t, n, i, e, r, o, l, m, s, d) {
                return a
            }
            t.toString;
            var r, o, l = /^amp\-(video|.+player)|AMP-BRIGHTCOVE|AMP-DAILYMOTION|AMP-YOUTUBE|AMP-VIMEO|AMP-IMA-VIDEO/i;

            function m(a) {
                return "AMP-VIDEO" != a && l.test(a)
            }

            function s(a) {
                var t = a.ownerDocument || a;
                return r && r.ownerDocument === t || (r = t.createElement("div")), d
            }

            function d(a) {
                return function(a, t) {
                    if (e(1 === t.length), e(Array.isArray(t) || (r = t, n.call(r, "raw"))), self.trustedTypes && self.trustedTypes.createPolicy) {
                        var i = self.trustedTypes.createPolicy("static-template#createNode", {
                            createHTML: function(a) {
                                return t[0]
                            }
                        });
                        a.innerHTML = i.createHTML("ignored")
                    } else a.innerHTML = t[0];
                    var r, o = a.firstElementChild;
                    return e(o), e(!o.nextElementSibling), a.removeChild(o), o
                }(r, a)
            }
            var f = ["Webkit", "webkit", "Moz", "moz", "ms", "O", "o"];

            function p(a) {
                var t = a.replace(/[A-Z]/g, (function(a) {
                    return "-" + a.toLowerCase()
                }));
                return f.some((function(a) {
                    return t.startsWith(a + "-")
                })) ? "-".concat(t) : t
            }

            function h(a, t, n) {
                if (t.startsWith("--")) return t;
                o || (o = i());
                var e = o[t];
                if (!e || n) {
                    if (e = t, void 0 === a[t]) {
                        var r = function(a) {
                                return a.charAt(0).toUpperCase() + a.slice(1)
                            }(t),
                            l = function(a, t) {
                                for (var n = 0; n < f.length; n++) {
                                    var i = f[n] + t;
                                    if (void 0 !== a[i]) return i
                                }
                                return ""
                            }(a, r);
                        void 0 !== a[l] && (e = l)
                    }
                    n || (o[t] = e)
                }
                return e
            }

            function c(a, t) {
                a.insertBefore(t, a.firstChild)
            }

            function u(a, t, n, i, e, r, o, l, m, s, d) {
                return a
            }

            function v(a, t, n) {
                if (t[n]) return t[n];
                var i = a.querySelector("style[".concat(n, "], link[").concat(n, "]"));
                return i ? (t[n] = i, i) : null
            }

            function w(a, t) {
                for (var n = a.styleSheets, i = 0; i < n.length; i++)
                    if (n[i].ownerNode == t) return !0;
                return !1
            }
            self.__AMP_LOG = self.__AMP_LOG || {
                user: null,
                dev: null,
                userForEmbed: null
            }, self.__AMP_LOG;
            var y, g = ['<div class=i-amphtml-new-loader-spinner-wrapper><svg class=i-amphtml-new-loader-spinner viewBox="0 0 48 48"><path class=i-amphtml-new-loader-spinner-path fill=none d="M24 2a22 22 0 10.01 0m33.27 5.65a22 22 0 102.74-2.1m46.13 1.35a22 22 0 105.96-3.44m42.96 2.74a22 22 0 109.49-3.93m39.46 3.28a22 22 0 1013.13-3.52M253 4.95a22 22 0 1016.69-2.2m32.32 1.65a22 22 0 1019.98 0m29.06-.5a22 22 0 1022.79 3m26.28-3.44a22 22 0 1024.98 6.69m24.1-7.07a22 22 0 1026.4 10.94m22.71-11.27a22 22 0 1026.94 15.56m22.18-15.83a22 22 0 1026.54 20.37m22.59-20.58a22 22 0 1025.17 25.17M645.7 2.12a22 22 0 1022.84 29.76m26.31-29.85a22 22 0 1019.6 33.95M744 2a22 22 0 1015.56 37.56m33.59-37.53a22 22 0 1010.83 40.42M842.3 2.12a22 22 0 105.58 42.42m43.56-42.27a22 22 0 100 43.46m49.13-43.25a22 22 0 10-5.73 43.49m54.85-43.22a22 22 0 10-11.39 42.5m60.5-42.17a22 22 0 00-16.79 40.53m65.87-40.15a22 22 0 00-21.73 37.64m70.8-37.2a22 22 0 00-26.05 33.94m75.09-33.44a22 22 0 00-29.59 29.59M1235 4.95a22 22 0 00-32.25 24.75m81.23-24.15a22 22 0 00-33.95 19.6m82.9-18.95a22 22 0 00-34.66 14.36m83.58-13.66a22 22 0 00-34.38 9.21m83.25-8.46a22 22 0 00-33.17 4.37m82.01-3.58a22 22 0 00-31.11 0m81.35 2.63a22 22 0 00-32.52-3.42m82.32 6.36a22 22 0 00-33.45-7.11m82.77 10.3a22 22 0 00-33.85-11m82.66 14.36a22 22 0 00-33.71-15.01M1726 24a22 22 0 00-33-19.05m80.73 22.49a22 22 0 00-31.72-23.04m78.91 26.4a22 22 0 00-29.87-26.9m76.55 30.09a22 22 0 00-27.49-30.53m73.69 33.47a22 22 0 00-24.6-33.85m70.36 36.48a22 22 0 00-21.25-36.81m66.62 39.05a22 22 0 00-17.51-39.32m62.57 41.12a22 22 0 00-13.43-41.33m58.24 42.65a22 22 0 00-9.1-42.8m53.74 43.61a22 22 0 00-4.59-43.7M2184 46a22 22 0 100-44m44.56 43.73a22 22 0 104.59-43.7m40.05 42.89a22 22 0 109.1-42.8m35.71 41.48a22 22 0 1013.43-41.33m31.63 39.53a22 22 0 1017.51-39.32m27.86 37.08a22 22 0 1021.25-36.81m24.51 34.18a22 22 0 1024.6-33.85m21.6 30.91a22 22 0 1027.49-30.53m19.19 27.34a22 22 0 1029.87-26.9m17.32 23.54a22 22 0 1031.72-23.04M2642 24a22 22 0 1033-19.05m15.27 15.61a22 22 0 1033.71-15.01m15.1 11.65a22 22 0 1033.85-11m15.47 7.81a22 22 0 1033.45-7.11m16.35 4.17a22 22 0 1032.52-3.42m17.72.79a22 22 0 1031.11 0m17.73-.79a22 22 0 1032.52 3.42m16.35-4.17a22 22 0 1033.45 7.11m15.47-7.81a22 22 0 1033.85 11m15.1-11.65a22 22 0 1033.71 15.01M3133 4.95A22 22 0 103166 24m16.01-19.6a22 22 0 1031.72 23.04m17.32-23.54a22 22 0 1029.87 26.9m19.2-27.34a22 22 0 1027.49 30.53m21.59-30.91a22 22 0 1024.6 33.85m24.51-34.18a22 22 0 1021.25 36.81m27.87-37.08a22 22 0 1017.51 39.32m31.62-39.53a22 22 0 1013.43 41.33m35.71-41.48a22 22 0 109.1 42.8m40.05-42.89a22 22 0 104.59 43.7M3624 2a22 22 0 100 44m49.15-43.97a22 22 0 00-4.59 43.7m53.74-43.61a22 22 0 00-9.1 42.8m58.24-42.65a22 22 0 00-13.43 41.33m62.56-41.12a22 22 0 00-17.51 39.32m66.63-39.05a22 22 0 00-21.25 36.81m70.36-36.48a22 22 0 00-24.6 33.85m73.68-33.47a22 22 0 00-27.49 30.53m76.56-30.09a22 22 0 00-29.87 26.9m78.91-26.4a22 22 0 00-31.72 23.04M4115 4.95A22 22 0 004082 24m81.98-18.45a22 22 0 00-33.71 15.01m82.66-14.36a22 22 0 00-33.85 11m82.77-10.3a22 22 0 00-33.45 7.11m82.32-6.36a22 22 0 00-32.52 3.42"></path></svg></div>'],
                M = ["<div class=i-amphtml-new-loader><div class=i-amphtml-new-loader-shim></div><div class=i-amphtml-new-loader-logo></div></div>"],
                x = ['<svg viewBox="0 0 72 72"><path class=i-amphtml-new-loader-white-on-shim fill=currentColor d=M41,34.5V31c0-0.5-0.4-1-1-1H27c-0.5,0-1,0.5-1,1v10c0,0.6,0.5,1,1,1h13c0.6,0,1-0.4,1-1v-3.5l5,4v-11L41,34.5z></path></svg>'],
                b = ['<svg class=i-amphtml-new-loader-logo-default viewBox="0 0 72 72"><circle cx=36 cy=36 r=12></circle></svg>'],
                A = ["<div class=i-amphtml-new-loader-ad-logo><span class=i-amphtml-new-loader-ad-label>Ad</span></div>"],
                k = {
                    "AMP-IMG": !0,
                    "AMP-ANIM": !0,
                    "AMP-PINTEREST": !0,
                    "AMP-INSTAGRAM": !0,
                    "AMP-GOOGLE-DOCUMENT-EMBED": !0
                },
                I = null,
                O = function() {
                    function a(a, t, n, i) {
                        this.Gn = a, this.aaa = t, this.taa = n, this.naa = i, this.iaa = null
                    }
                    var t = a.prototype;
                    return t.build = function() {
                        this.iaa = function(a) {
                            if (!I) {
                                var t = s(a);
                                (I = t(M)).appendChild(function(a) {
                                    return a(g)
                                }(t))
                            }
                            return I.cloneNode(!0)
                        }(this.Gn), this.aaa.appendChild(this.iaa), this.eaa(), this.raa()
                    }, t.raa = function() {
                        this.oaa() || this.laa() || (this.zp(), this.maa() && this.iaa.classList.add("i-amphtml-new-loader-has-shim"), this.saa())
                    }, t.zp = function() {
                        var a = "i-amphtml-new-loader-size-default";
                        return this.daa() ? this.iaa.classList.add(a) : this.faa() ? this.iaa.classList.add("i-amphtml-new-loader-size-small") : this.paa() ? this.iaa.classList.add("i-amphtml-new-loader-size-large") : this.iaa.classList.add(a)
                    }, t.saa = function() {
                        var a = this.haa(),
                            t = a.color,
                            n = a.content,
                            i = void 0 === n ? this.caa() : n;
                        this.iaa.querySelector(".i-amphtml-new-loader-logo").appendChild(i), t && function(a, t, n, i, e) {
                            var r = h(a.style, "color", void 0);
                            if (r) {
                                var o = n;
                                a.style.setProperty(p(r), o)
                            }
                        }(this.iaa, 0, t)
                    }, t.uaa = function() {
                        var a = !!this.Gn.getPlaceholder(),
                            t = this.Gn.hasAttribute("poster");
                        return a || t
                    }, t.vaa = function() {
                        var a = this.Gn.tagName;
                        return k[a] || m(a)
                    }, t.eaa = function() {
                        !this.uaa() && this.vaa() && this.aaa.classList.add("i-amphtml-loader-background")
                    }, t.haa = function() {
                        return this.daa() ? {
                            content: this.waa()
                        } : m(this.Gn.tagName) ? {
                            content: this.yaa()
                        } : this.Gn.createLoaderLogo()
                    }, t.yaa = function() {
                        return s(this.Gn)(x)
                    }, t.caa = function() {
                        return s(this.Gn)(b)
                    }, t.waa = function() {
                        return s(this.Gn)(A)
                    }, t.daa = function() {
                        return "AMP-AD" == this.Gn.tagName
                    }, t.faa = function() {
                        return !this.oaa() && (this.taa <= 100 || this.naa <= 100)
                    }, t.oaa = function() {
                        return this.taa < 50 || this.naa < 50
                    }, t.laa = function() {
                        var a = this.Gn.getPlaceholder();
                        return a && a.classList.contains("i-amphtml-blurry-placeholder")
                    }, t.maa = function() {
                        if (this.Gn.hasAttribute("poster")) return !0;
                        var a = this.Gn.getPlaceholder();
                        return !!a && ("AMP-IMG" == a.tagName || "IMG" == a.tagName)
                    }, t.paa = function() {
                        return !1
                    }, a
                }(),
                P = function() {
                    function a() {}
                    return a.prototype.initializeLoader = function(a, t, n, i, e) {
                        var r = Math.min(n, 600);
                        new O(a, t, i, e).build(),
                            function(a, t) {
                                var n = a.style;
                                for (var i in t) n.setProperty(p(h(n, i)), String(t[i]), "important")
                            }(a, {
                                "--loader-delay-offset": "".concat(r, "ms")
                            })
                    }, a
                }();
            a.registerServiceForDoc("loader", P), (y = a.win, function(a, t) {
                return function(a, t) {
                    u(function(a, t) {
                        var n = a.__AMP_SERVICES && a.__AMP_SERVICES[t];
                        return !(!n || !n.ctor)
                    }(a, t));
                    var n = function(a) {
                        var t = a.__AMP_SERVICES;
                        return t || (t = a.__AMP_SERVICES = {}), t
                    }(a)[t];
                    return n.obj || (u(n.ctor), u(n.context), n.obj = new n.ctor(n.context), u(n.obj), n.context = null, n.resolve && n.resolve(n.obj)), n.obj
                }(a = function(a) {
                    return a.__AMP_TOP || (a.__AMP_TOP = a)
                }(a), t)
            }(y, "extensions")).addDocFactory((function(a) {
                ! function(a, t, n, e, r) {
                    var o = a.getHeadNode(),
                        l = function(a, t, n, e) {
                            var r = a.__AMP_CSS_SM;
                            r || (r = a.__AMP_CSS_SM = i());
                            var o = "amp-extension=".concat(e);
                            if (o) {
                                var l = v(a, r, o);
                                if (l) return "STYLE" == l.tagName && l.textContent !== t && (l.textContent = t), l
                            }
                            var m = (a.ownerDocument || a).createElement("style");
                            m.textContent = t;
                            return m.setAttribute("amp-extension", e),
                                function(a, t) {
                                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
                                    if (n) {
                                        var i = n.nextSibling;
                                        a.insertBefore(t, i)
                                    } else c(a, t)
                                }(a, m, v(a, r, "amp-runtime")), o && (r[o] = m), m
                        }(o, function(a, t) {
                            var n = a.__AMP_CSS_TR;
                            return n ? n(t) : t
                        }(o, ".i-amphtml-loader-background{position:absolute;top:0;left:0;bottom:0;right:0;background-color:#f8f8f8}.i-amphtml-new-loader{display:inline-block;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:0;height:0;color:#aaa}.i-amphtml-new-loader-size-default,.i-amphtml-new-loader-size-small{width:72px;height:72px}.i-amphtml-new-loader-logo{transform-origin:center;opacity:0;animation:i-amphtml-new-loader-scale-and-fade-in 0.8s ease-in forwards;animation-delay:0.6s;animation-delay:calc(0.6s - var(--loader-delay-offset))}.i-amphtml-new-loader-size-small .i-amphtml-new-loader-logo{display:none}.i-amphtml-new-loader-logo-default{fill:currentColor;animation:i-amphtml-new-loader-fade-out 0.8s ease-out forwards;animation-delay:1.8s;animation-delay:calc(1.8s - var(--loader-delay-offset))}.i-amphtml-new-loader-has-shim{color:#fff!important}.i-amphtml-new-loader-shim{width:72px;height:72px;border-radius:50%;display:none;transform-origin:center;opacity:0;background-color:rgba(0,0,0,0.6);animation:i-amphtml-new-loader-scale-and-fade-in 0.8s ease-in forwards;animation-delay:0.6s;animation-delay:calc(0.6s - var(--loader-delay-offset))}.i-amphtml-new-loader-size-small .i-amphtml-new-loader-shim{width:48px;height:48px;margin:12px}.i-amphtml-new-loader-has-shim .i-amphtml-new-loader-shim{display:initial}.i-amphtml-new-loader-has-shim .i-amphtml-new-loader-logo-default{display:none}.i-amphtml-new-loader-has-shim .i-amphtml-new-loader-transparent-on-shim{fill:transparent!important}.i-amphtml-new-loader-logo,.i-amphtml-new-loader-shim,.i-amphtml-new-loader-spinner-wrapper{position:absolute;top:0;left:0;bottom:0;right:0}.i-amphtml-new-loader-spinner-wrapper{margin:12px}.i-amphtml-new-loader-spinner{stroke:currentColor;stroke-width:1.5px;opacity:0;animation:i-amphtml-new-loader-fade-in 0.8s ease-in forwards;animation-delay:1.8s;animation-delay:calc(1.8s - var(--loader-delay-offset))}.i-amphtml-new-loader-spinner-path{animation:frame-position-first-spin 0.6s steps(30),frame-position-infinite-spin 1.2s steps(59) infinite;animation-delay:2.8s,3.4s;animation-delay:calc(2.8s - var(--loader-delay-offset)),calc(3.4s - var(--loader-delay-offset))}.i-amphtml-new-loader-size-small .i-amphtml-new-loader-spinner{transform:scale(0.54545);stroke-width:2.75px}.i-amphtml-new-loader-size-small .i-amphtml-new-loader-spinner-path{animation-delay:1.4s,2s;animation-delay:calc(1.4s - var(--loader-delay-offset)),calc(2s - var(--loader-delay-offset))}.i-amphtml-new-loader *{animation-play-state:paused}.amp-active>.i-amphtml-new-loader *{animation-play-state:running}.i-amphtml-new-loader-ad-logo{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;width:100%;height:100%}.i-amphtml-new-loader-ad-label{all:initial!important;display:inline-block!important;padding:0 0.4ch!important;border:1px solid!important;border-radius:2px!important;color:currentColor!important;font-size:11px!important;font-family:sans-serif!important;line-height:1.1!important;visibility:inherit!important}@keyframes i-amphtml-new-loader-fade-in{0%{opacity:0}to{opacity:1}}@keyframes i-amphtml-new-loader-fade-out{0%{opacity:1}to{opacity:0}}@keyframes i-amphtml-new-loader-scale-and-fade-in{0%{opacity:0;transform:scale(0)}50%{transform:scale(1)}to{opacity:1}}@keyframes frame-position-first-spin{0%{transform:translateX(0)}to{transform:translateX(-1440px)}}@keyframes frame-position-infinite-spin{0%{transform:translateX(-1440px)}to{transform:translateX(-4272px)}}\n/*# sourceURL=/extensions/amp-loader/0.1/amp-loader.css*/"), 0, "amp-loader");
                    if (n) {
                        var m = a.getRootNode();
                        if (w(m, l)) return l;
                        var s = setInterval((function() {
                            w(m, l) && clearInterval(s)
                        }), 4)
                    }
                }(a, 0, (function() {}))
            }))
        }();
        /*! https://mths.be/cssescape v1.5.1 by @mathias | MIT license */
    }
});
//# sourceMappingURL=amp-loader-0.1.js.map